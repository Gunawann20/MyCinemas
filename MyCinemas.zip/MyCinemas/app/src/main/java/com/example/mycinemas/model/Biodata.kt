package com.example.mycinemas.model

data class Biodata(
    val image: Int,
    val nama: String,
    val email: String
)
